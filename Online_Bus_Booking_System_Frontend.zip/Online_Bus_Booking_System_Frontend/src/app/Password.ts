export class Password{
    oldPassword:string;
    newPassword:string;
    confirmPassword:string;
}