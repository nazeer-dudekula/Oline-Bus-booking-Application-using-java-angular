export class Passenger{
    passengerId:number;
    passengerName:string;
    passengerAge:number;
    seatNo:string;
    gender:string;
}