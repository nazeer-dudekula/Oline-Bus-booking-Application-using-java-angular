export class LoginForgetDto{
    id:number;
    email:String;
}