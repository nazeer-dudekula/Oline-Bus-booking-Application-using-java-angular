export class LoginDto{
    id:number
   
    password:string;


}