export class Bus {
    busId: number;
    busName: string;
   // noOfSeats: number;
    duration: string;
    typeOfBus: string;
    timeOfDeparture: String;
    timeOfArrival: String;

    fare: number;
    source: string;
    destination: string;
}