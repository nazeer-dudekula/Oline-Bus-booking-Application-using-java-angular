package com.obs.resource;

import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import com.obs.entity.*;
import com.obs.service.BusReservationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;

@RestController
@CrossOrigin
@Api(value = "Bus Reservation API")
public class BusReservationController {

    private static final Logger logger = LoggerFactory.getLogger(BusReservationController.class);

    @Autowired
    BusReservationService busService;

    @ApiOperation(value = "Register or update a user")
    @PostMapping(value = "/registerorupdateuser")
    public User registerOrUpdateUser(@RequestBody User user) {
        logger.info("Registering or updating user: {}", user.getUserId());
        User userPersisted = busService.registerOrUpdateUser(user);
        logger.info("User registered or updated: {}", user.getUserId());
        return userPersisted;
    }

   @ApiOperation(value = "Add or update a bus")
    @PostMapping(value = "/addorupdatebus")
    public Bus addBus(@RequestBody Bus bus) {
        logger.info("Adding or updating bus: {}", bus.getbusId());
        Bus busPersisted = busService.addBus(bus);
        logger.info("Bus added or updated: {}", bus.getbusId());
        return busPersisted;
    }

    @ApiOperation(value = "Update a bus")
    @GetMapping(value = "/updatebus")
    public int updateBus(
            @ApiParam(value = "Bus ID", required = true) @RequestParam("busId") int busId,
            @ApiParam(value = "Source", required = true) @RequestParam("source") String source,
            @ApiParam(value = "Destination", required = true) @RequestParam("destination") String destination,
            @ApiParam(value = "Fare", required = true) @RequestParam("fare") double fare) {
        logger.info("Updating bus: {}", busId);
        int res = busService.updateBus(busId, source, destination, fare);
        logger.info("Bus updated: {}", busId);
        return res;
    }

    @ApiOperation(value = "User login")
    @PostMapping(value = "/login")
    public boolean login(@RequestBody LoginDto dto) {
        logger.info("User login request for ID: {}", dto.getId());
        boolean userPersisted = busService.loginUser(dto.getId(), dto.getPassword());
        logger.info("User login result for ID {}: {}", dto.getId(), userPersisted);
        return userPersisted;
    }

    @ApiOperation(value = "Admin login")
    @PostMapping(value = "/loginadmin")
    public Boolean loginAdmin(@RequestBody LoginDto dto) {
        logger.info("Admin login request for ID: {}", dto.getId());
        Boolean adminPersisted = busService.loginAdmin(dto.getId(), dto.getPassword());
        logger.info("Admin login result for ID {}: {}", dto.getId(), adminPersisted);
        return adminPersisted;
    }

    @ApiOperation(value = "Change password")
    @PutMapping(value = "/changepassword")
    public boolean changePassword(@RequestBody ChangePasswordDto dto) {
        logger.info("Changing password for user ID: {}", dto.getUserId());
        boolean result = busService.changePassword(dto.getUserId(), dto.getPassword());
        logger.info("Password changed for user ID: {}", dto.getUserId());
        return result;
    }

    @ApiOperation(value = "Book a ticket")
    @PostMapping(value = "/bookaticket")
    public Ticket bookATicket(@RequestBody BookTicket bookTicket, @RequestParam("userId") int userId,
                              @RequestParam("busId") int busId) {
        Ticket ticket = bookTicket.getTicket();
        Bus bus = busService.chooseBus(busId);
        ticket.setBus(bus);
        User user = busService.findUser(userId);
        ticket.setUser(user);
        List<Passenger> passengers = bookTicket.getPassengers();
        ticket.setPassengers(passengers);
        for (int i = 0; i < passengers.size(); i++) {
            passengers.get(i).setTicket(ticket);
        }
        logger.info("Booking a ticket for user ID: {}", userId);
        return busService.bookATicket(ticket);
    }

    @ApiOperation(value = "Add a ticket to a user")
    @GetMapping(value = "/addtickettouser")
    public Ticket addTicketToUserId(@RequestParam("ticketId") int ticketId, @RequestParam("userId") int userId) {
        Ticket ticket1 = busService.ticketDetails(ticketId);
        User user1 = busService.findUser(userId);
        ticket1.setUser(user1);
        Ticket ticketPersisted = busService.setTicketForUser(ticket1);
        logger.info("Adding a ticket to user ID: {}", userId);
        return ticketPersisted;
    }

   

        @GetMapping(value = "/sendmailonregistration")
        public boolean successRegistration(@RequestParam int userId) {
            logger.info("Sending registration email for user with ID: {}", userId);
            User user = busService.findUser(userId);
            busService.sendEmailOnRegistration(user);
            return true;
        }

        @GetMapping(value = "/sendEmail")
        public boolean success(@RequestParam("ticketId") int ticketId) {
            logger.info("Sending email for booking with ticket ID: {}", ticketId);
            Ticket ticket1 = busService.ticketDetails(ticketId);
            boolean result = busService.sendEmailOnBooking(ticket1);
            return result;
        }

        @ApiOperation(value = "Search for buses")
        @GetMapping(value = "/searchbus")
        public List<Bus> searchBus(
                @ApiParam(value = "Source", required = true) @RequestParam("source") String source,
                @ApiParam(value = "Destination", required = true) @RequestParam("destination") String destination) {
            logger.info("Searching for buses from {} to {}", source, destination);
            return busService.searchBus(source, destination);
        }

        @ApiOperation(value = "Get bus details by ID")
        @GetMapping(value = "/getbusbyid")
        public Bus chooseBus(
                @ApiParam(value = "Bus ID", required = true) @RequestParam("busId") int busId) {
            logger.info("Getting bus details for bus ID: {}", busId);
            return busService.chooseBus(busId);
        }

        @ApiOperation(value = "Fetch booked seats for a specific bus and date")
        @GetMapping(value = "/fetchbookedseats")
        public List<String> fetchBookedSeats(
                @ApiParam(value = "Travel Date", required = true) @RequestParam("travelDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
                @ApiParam(value = "Bus ID", required = true) @RequestParam("busId") int busId) {
            logger.info("Fetching booked seats for bus ID: {} on travel date: {}", busId, travelDate);
            return busService.fetchBookedSeats(travelDate, busId);
        }

        @ApiOperation(value = "Get frequently traveled routes")
        @GetMapping(value = "/frequentlytravelledroute")
        public List<Object[]> frequentlyTravelledRoute() {
            logger.info("Getting frequently traveled routes");
            return busService.frequentlyTravelledRoute();
        }

        @ApiOperation(value = "View all buses")
        @GetMapping(value = "/viewallbuses")
        public List<Bus> viewAllBuses() {
            logger.info("Viewing all buses");
            return busService.viewAllBuses();
        }

        @ApiOperation(value = "View all registered customers")
        @GetMapping(value = "/viewallregsiteredcustomers")
        public List<User> viewAllRegsiteredCustomers() {
            logger.info("Viewing all registered customers");
            return busService.viewAllRegsiteredCustomers();
        }

        @ApiOperation(value = "View customers who registered but have no bookings")
        @GetMapping(value = "/viewcustomerwhoregisteredbutwithnobooking")
        public List<User> viewCustomerWhoRegisteredButwithNoBooking() {
            logger.info("Viewing customers who registered but have no bookings");
            return busService.viewCustomerWhoRegisteredButwithNoBooking();
        }

        @ApiOperation(value = "Recharge a user's wallet")
        @GetMapping(value = "/rechargeWallet")
        public User rechargeWallet(
                @ApiParam(value = "User ID", required = true) @RequestParam("userId") int userId,
                @ApiParam(value = "Recharge Amount", required = true) @RequestParam("rechargeAmount") int rechargeAmount) {
            logger.info("Recharging wallet for user ID: {} with amount: {}", userId, rechargeAmount);
            return busService.rechargeWallet(userId, rechargeAmount);
        }

        @ApiOperation(value = "Get ticket details")
        @GetMapping(value = "/ticketDetails")
        public Ticket ticketDetails(
                @ApiParam(value = "Ticket ID", required = true) @RequestParam("ticketId") int ticketId) {
            logger.info("Getting ticket details for ticket ID: {}", ticketId);
            return busService.ticketDetails(ticketId);
        }

        @ApiOperation(value = "Pay through wallet")
        @GetMapping(value = "/paythroughwallet")
        public boolean payThroughWallet(
                @ApiParam(value = "User ID", required = true) @RequestParam("userId") int userId,
                @ApiParam(value = "Amount", required = true) @RequestParam("amount") double amount) {
            logger.info("Paying through wallet for user ID: {} with amount: {}", userId, amount);
            return busService.payThroughWallet(userId, amount);
        }

        @ApiOperation(value = "Get the most preferred buses")
        @GetMapping(value = "/mostpreferredbus")
        public List<Integer> mostPreferredBus() {
            logger.info("Getting the most preferred buses");
            return busService.mostPreferredBus();
        }

        @ApiOperation(value = "Cancel a ticket")
        @DeleteMapping(value = "/cancelticket")
        public boolean cancelTicket(
                @ApiParam(value = "Ticket ID", required = true) @RequestParam("ticketId") int ticketId) {
            logger.info("Cancelling ticket with ID: {}", ticketId);
            return busService.cancelTicket(ticketId);
        }

        @ApiOperation(value = "View tickets booked by a user")
        @GetMapping(value = "/viewticketbookedbyuserid")
        public List<Ticket> viewTicketBookedByUserId(
                @ApiParam(value = "User ID", required = true) @RequestParam("userId") int userId) {
            logger.info("Viewing tickets booked by user with ID: {}", userId);
            return busService.viewTicketBookedByUserId(userId);
        }

        @ApiOperation(value = "Get passenger list for a ticket")
        @GetMapping(value = "/getPassengerList")
        public List<Passenger> getPassengerList(
                @ApiParam(value = "Ticket ID", required = true) @RequestParam("ticketId") int ticketId) {
            logger.info("Getting passenger list for ticket ID: {}", ticketId);
            return busService.getPassenger(ticketId);
        }

        @ApiOperation(value = "Get bus details by ticket ID")
        @GetMapping(value = "/getBusByTicketId")
        public Bus getBusByTicketId(
                @ApiParam(value = "Ticket ID", required = true) @RequestParam("ticketId") int ticketId) {
            logger.info("Getting bus details by ticket ID: {}", ticketId);
            return busService.getBus(ticketId);
        }

        @ApiOperation(value = "Find user by ID")
        @GetMapping(value = "finduserbyid")
        public User findUser(
                @ApiParam(value = "User ID", required = true) @RequestParam int userId) {
            logger.info("Finding user by ID: {}", userId);
            return busService.findUser(userId);
        }

        @ApiOperation(value = "Find bookings based on period")
        @GetMapping(value = "bookingsbasedonperiod")
        public List<Ticket> findBookingBasedOnPeriod(
                @ApiParam(value = "Bus ID", required = true) @RequestParam("busId") int busId,
                @ApiParam(value = "Travel Date", required = true) @RequestParam("travelDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate) {
            logger.info("Finding bookings based on period for bus ID: {} and travel date: {}", busId, travelDate);
            return busService.bookingsBasedOnPeriod(busId, travelDate);
        }

        @ApiOperation(value = "Login and reset password")
        @PostMapping(value = "/loginforgetpassword")
        public User loginForgetPassword(@RequestBody LoginForgetDto dto1) {
            logger.info("Logging in and resetting password for user ID: {} and email: {}", dto1.getId(), dto1.getEmail());
            User loginPersisted = busService.forgotPassword(dto1.getId(), dto1.getEmail());
            busService.sendEmailOnForgetPassword(loginPersisted);
            return loginPersisted;
        }

        @ApiOperation(value = "Reschedule a ticket")
        @PutMapping(value = "reschedule")
        public Ticket reschedule(
                @ApiParam(value = "Ticket ID", required = true) @RequestParam("ticketId") int ticketId,
                @ApiParam(value = "Travel Date", required = true) @RequestParam("travelDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
                @RequestBody List<String> seats) {
            logger.info("Rescheduling ticket with ID: {} to travel date: {}", ticketId, travelDate);
            return busService.rescheduleTicket(ticketId, travelDate, seats);
        }
    }