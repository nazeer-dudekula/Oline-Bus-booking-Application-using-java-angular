package com.obs.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.obs.entity.Admin;
import com.obs.entity.Bus;
import com.obs.entity.Passenger;
import com.obs.entity.Ticket;
import com.obs.entity.User;
import com.obs.exception.CustomerServiceException;
import com.obs.repository.BusReservationDao;

@Service
public class BusReservationServiceImpl implements BusReservationService {

    private static final Logger logger = LoggerFactory.getLogger(BusReservationServiceImpl.class);

    @Autowired
    BusReservationDao busDao;

    @Autowired
    EmailService emailservice;

    public User registerOrUpdateUser(User user) {
        logger.info("Registering or updating user: {}", user.getUserId());
        return busDao.registerOrUpdateUser(user);
    }

    public Bus addBus(Bus bus) {
        logger.info("Adding a new bus: {}", bus.getbusId());
        return busDao.addBus(bus);
    }

    public boolean loginUser(int userId, String password) {
        logger.info("Logging in user with ID: {}", userId);
        return busDao.loginUser(userId, password);
    }

    public boolean changePassword(int userId, String password) {
        logger.info("Changing password for user with ID: {}", userId);
        return busDao.changePassword(userId, password);
    }

    public Ticket bookATicket(Ticket ticket) {
        logger.info("Booking a ticket for user with ID: {}", ticket.getUser().getUserId());
        return busDao.bookATicket(ticket);
    }

    public List<Bus> searchBus(String source, String destination) {
        logger.info("Searching for buses from {} to {}", source, destination);
        return busDao.searchBus(source, destination);
    }

    public Bus chooseBus(int busId) {
        logger.info("Choosing bus with ID: {}", busId);
        return busDao.chooseBus(busId);
    }

    public List<String> fetchBookedSeats(LocalDate travelDate, int busId) {
        logger.info("Fetching booked seats for bus ID: {} on travel date: {}", busId, travelDate);
        return busDao.fetchBookedSeats(travelDate, busId);
    }

    public List<Object[]> frequentlyTravelledRoute() {
        logger.info("Getting frequently traveled routes");
        return busDao.frequentlyTravelledRoute();
    }

    public List<Bus> viewAllBuses() {
        logger.info("Viewing all buses");
        return busDao.viewAllBuses();
    }

    public List<User> viewAllRegsiteredCustomers() {
        logger.info("Viewing all registered customers");
        return busDao.viewAllRegsiteredCustomers();
    }

    public List<User> viewCustomerWhoRegisteredButwithNoBooking() {
        logger.info("Viewing customers who registered but have no bookings");
        return busDao.viewCustomerWhoRegisteredButwithNoBooking();
    }

    public User rechargeWallet(int userId, int rechargeAmount) {
        logger.info("Recharging wallet for user with ID: {} with amount: {}", userId, rechargeAmount);
        return busDao.rechargeWallet(userId, rechargeAmount);
    }

    public Ticket ticketDetails(int ticketId) {
        logger.info("Getting ticket details for ticket ID: {}", ticketId);
        return busDao.ticketDetails(ticketId);
    }

    public boolean payThroughWallet(int userId, double amount) {
        logger.info("Paying through wallet for user with ID: {} with amount: {}", userId, amount);
        return busDao.payThroughWallet(userId, amount);
    }

    public List<Integer> mostPreferredBus() {
        logger.info("Getting the most preferred buses");
        return busDao.mostPreferredBus();
    }

    public boolean cancelTicket(int ticketId) {
        logger.info("Canceling ticket with ID: {}", ticketId);
        return busDao.cancelTicket(ticketId);
    }

    public List<Ticket> viewTicketBookedByUserId(int userId) {
        logger.info("Viewing tickets booked by user with ID: {}", userId);
        return busDao.viewTicketBookedByUserId(userId);
    }

    @Override
    public User findUser(int userId) {
        logger.info("Finding user with ID: {}", userId);
        return busDao.findUser(userId);
    }

    @Override
    public Boolean loginAdmin(int adminId, String password) {
        logger.info("Logging in admin with ID: {}", adminId);
        return busDao.loginAdmin(adminId, password);
    }

    @Override
    public List<Passenger> getPassenger(int ticketId) {
        logger.info("Getting passenger list for ticket with ID: {}", ticketId);
        return busDao.getPassenger(ticketId);
    }

    @Override
    public Bus getBus(int ticketId) {
        logger.info("Getting bus details for ticket with ID: {}", ticketId);
        return busDao.getBus(ticketId);
    }

    @Override
    public int updateBus(int busId, String source, String destination, double fare) {
        logger.info("Updating bus with ID: {}, source: {}, destination: {}, and fare: {}", busId, source, destination, fare);
        return busDao.updateBus(busId, source, destination, fare);
    }

    @Override
    public List<Ticket> bookingsBasedOnPeriod(int busId, LocalDate travelDate) {
        logger.info("Finding bookings for bus ID: {} on travel date: {}", busId, travelDate);
        return busDao.bookingsBasedOnPeriod(busId, travelDate);
    }

    @Override
    public void sendEmailOnRegistration(User user) {
        logger.info("Sending registration confirmation email to user with ID: {}", user.getUserId());
        String subject = "Registration confirmation";
        String text = "Hi " + user.getFirstName() + "\n " + " You have been Successfully registered. \n"
                + "Your userId is " + user.getUserId() + ".\n " + "Please use this to login";
        emailservice.sendEmailForNewRegistration(user.getEmail(), text, subject);
        logger.info("Registration confirmation email sent");
    }

    @Override
    public boolean sendEmailOnBooking(Ticket ticket) {
        logger.info("Sending booking confirmation email to user with ID: {}", ticket.getUser().getUserId());
        String subject = "Ticket confirmation";
        StringBuilder text = new StringBuilder();
        text.append("Hi " + ticket.getUser().getFirstName() + ".\n " + "Your ticket has been successfully booked.\n"
                + "Your Ticket Id is " + ticket.getTicketId() + ".\n " + "Source : " + ticket.getBus().getSource()
                + " Destination : " + ticket.getBus().getDestination() + "\n" + "Departure Time : "
                + ticket.getBus().getTimeOfDeparture() + " Arrival Time : " + ticket.getBus().getTimeOfArrival()
                + "\n");

        for (int i = 0; i < ticket.getNoOfPassengers(); i++) {
            text.append("Passenger Name : " + ticket.getPassengers().get(i).getPassengerName() + "   Passenger SeatNo : "
                    + ticket.getPassengers().get(i).getSeatNo() + "\n");
        }

        text.append("Total Amount : " + ticket.getTotalAmount() + "\n");
        
        text.append("Happy Journey & enjoy your trip!!!");

        emailservice.sendEmailForBooking(ticket.getEmail(), text.toString(), subject);
        logger.info("Booking confirmation email sent");
        return true;
    }


    public User forgotPassword(int userId, String email) {
        logger.info("Initiating forgot password process for user with ID: {}", userId);
        return busDao.forgotPassword(userId, email);
    }

    @Override
    public void sendEmailOnForgetPassword(User user) {
        logger.info("Sending forget password email to user with ID: {}", user.getUserId());
        String subject = "Please click on the link given below to reset the password.";
        String text = "Your reset password link : " + "http://localhost:4200/forgotLink";
        emailservice.sendEmailForForgetPassword(user.getEmail(), subject, text);
        logger.info("Forget password email sent");
    }

    @Override
    public Ticket rescheduleTicket(int ticketId, LocalDate travelDate, List<String> seats) {
        logger.info("Rescheduling ticket with ID: {} for new travel date: {} and seats: {}", ticketId, travelDate, seats);
        return busDao.rescheduleTicket(ticketId, travelDate, seats);
    }

    @Override
    public Ticket setTicketForUser(Ticket ticket) {
        logger.info("Setting ticket for user with ID: {}", ticket.getUser().getUserId());
        return busDao.setTicketForUser(ticket);
    }
}
