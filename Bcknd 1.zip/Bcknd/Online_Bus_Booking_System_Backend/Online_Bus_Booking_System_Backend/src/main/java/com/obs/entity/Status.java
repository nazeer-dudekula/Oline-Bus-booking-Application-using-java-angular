package com.obs.entity;

public enum Status {

	BOOKED,CANCELLED
	
}
