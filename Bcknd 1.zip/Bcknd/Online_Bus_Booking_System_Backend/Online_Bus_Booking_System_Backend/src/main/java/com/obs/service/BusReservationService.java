package com.obs.service;

import java.time.LocalDate;
import java.util.List;

import com.obs.entity.Admin;
import com.obs.entity.Bus;
import com.obs.entity.Passenger;
import com.obs.entity.Ticket;
import com.obs.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public interface BusReservationService {

    Logger logger = LoggerFactory.getLogger(BusReservationService.class);

    public User registerOrUpdateUser(User user);

    public Bus addBus(Bus bus);

    public User forgotPassword(int userId, String email);

    public void sendEmailOnForgetPassword(User user);

    public boolean loginUser(int userId, String password);

    public boolean changePassword(int userId, String password);

    public Ticket bookATicket(Ticket ticket);

    public List<Bus> searchBus(String source, String destination);

    public Bus chooseBus(int busId);

    public List<String> fetchBookedSeats(LocalDate travelDate, int busId);

    public List<Object[]> frequentlyTravelledRoute();

    public List<Bus> viewAllBuses();

    public List<User> viewAllRegsiteredCustomers();

    public List<User> viewCustomerWhoRegisteredButwithNoBooking();

    public User rechargeWallet(int userId, int rechargeAmount);

    public Ticket ticketDetails(int ticketId);

    public boolean payThroughWallet(int userId, double amount);

    public List<Integer> mostPreferredBus();

    public boolean cancelTicket(int ticketId);

    public List<Ticket> viewTicketBookedByUserId(int userId);

    public User findUser(int userId);

    public Boolean loginAdmin(int adminId, String password);

    public List<Passenger> getPassenger(int ticketId);

    public Bus getBus(int ticketId);

    public int updateBus(int busId, String source, String destination, double fare);

    public List<Ticket> bookingsBasedOnPeriod(int busId, LocalDate travelDate);

    public boolean sendEmailOnBooking(Ticket ticket);

    public void sendEmailOnRegistration(User user);

    public Ticket setTicketForUser(Ticket ticket);

    public Ticket rescheduleTicket(int ticketId, LocalDate travelDate, List<String> seats);
}
