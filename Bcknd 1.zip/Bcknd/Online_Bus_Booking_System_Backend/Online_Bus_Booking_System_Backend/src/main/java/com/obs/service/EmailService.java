package com.obs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private MailSender mailSender;

    public void sendEmailForNewRegistration(String email, String text, String subject) {
        logger.info("Sending registration email to: {}", email);
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("nazeerdudekula143@gmail.com");
        message.setTo(email);
        message.setSubject(subject);
        message.setText(text);
        mailSender.send(message);
        logger.info("Registration email sent to: {}", email);
    }

    public void sendEmailForBooking(String email, String string, String subject) {
        logger.info("Sending booking email to: {}", email);
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("nazeerdudekula143@gmail.com");
        message.setTo(email);
        message.setSubject(subject);
        message.setText(string.toString());
        mailSender.send(message);
        logger.info("Booking email sent to: {}", email);
    }

    public void sendEmailForForgetPassword(String email, String subject, String text) {
        logger.info("Sending forget password email to: {}", email);
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("nazeerdudekula143@gmail.com");
        message.setTo(email);
        message.setSubject(subject);
        message.setText(text);
        mailSender.send(message);
        logger.info("Forget password email sent to: {}", email);
    }
}
